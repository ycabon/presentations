//>>built
define({popupLabel:"Spalten ein- oder ausblenden"});