//>>built
define({popupLabel:"Mostra o nascondi colonne"});