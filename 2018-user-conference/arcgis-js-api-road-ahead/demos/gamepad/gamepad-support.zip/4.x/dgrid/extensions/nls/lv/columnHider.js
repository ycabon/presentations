//>>built
define({popupLabel:"R\u0101d\u012bt vai pasl\u0113pt kolonnas"});