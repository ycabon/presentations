//>>built
define({popupTriggerLabel:"Poka\u017ei ali skrij stolpce",popupLabel:"Poka\u017ei ali skrij stolpce"});