//>>built
define({previousMessage:"Prethodni izbori",nextMessage:"Jo\u0161 izbora"});